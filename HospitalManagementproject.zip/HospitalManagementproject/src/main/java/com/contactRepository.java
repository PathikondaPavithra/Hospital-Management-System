package com;

import org.springframework.data.jpa.repository.JpaRepository;

public interface contactRepository extends JpaRepository<contact,Integer> {

}
