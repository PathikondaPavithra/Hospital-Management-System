package com;

import org.springframework.data.jpa.repository.JpaRepository;

public interface loginRepository extends JpaRepository<login, String> {

}
